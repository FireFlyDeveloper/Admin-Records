--
-- PostgreSQL database dump
--

\restrict ukVt9jxwK6B1ZDlrd611ev4txBtMLN1NbUeCuydBdckVh6qp7twEfNJ6jpnFwcw

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, display_name, password_hash, is_active, created_at, updated_at, deleted_at) FROM stdin;
61825833-e8b8-41c7-b1ba-50f931c3ec96	admin@local	System Admin	$2b$10$VvjSt6NuVU5pWLzXXgFKBuNc4hKXX9u2d3YzBQvJ0u6j.g8Ez1bD2	t	2026-06-16 09:13:25.687227+00	2026-06-16 14:34:08.389122+00	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_id, action, entity_type, entity_id, before_state, after_state, ip_address, created_at) FROM stdin;
e03dea02-5d28-4b27-9530-fecc3b02e8b2	61825833-e8b8-41c7-b1ba-50f931c3ec96	create_item	item	3f37262a-7606-4ce2-85e1-ee300b7540f1	\N	{"name": "Korean Blueberry", "item_type": "quantifiable"}	\N	2026-06-16 09:24:24.722412+00
8c6f99e7-6371-4d87-89a0-73efd005cbbc	\N	device_offline	device	186532dc-4713-44c1-9963-c03c22a0273b	\N	{"room_id": null, "device_code": "A1", "offline_since": "2026-06-16T09:36:05.482Z", "last_heartbeat": null}	\N	2026-06-16 09:36:05.483243+00
827e6524-faa1-440a-be66-d7b2b84bf9cc	61825833-e8b8-41c7-b1ba-50f931c3ec96	create_item	item	638a8750-eef2-4300-b6aa-af85c71e269b	\N	{"name": "Charger", "item_type": "trackable"}	\N	2026-06-16 09:36:55.056953+00
36b61165-1e08-4fe4-8078-5376b86f52c0	61825833-e8b8-41c7-b1ba-50f931c3ec96	delete_item	item	3f37262a-7606-4ce2-85e1-ee300b7540f1	\N	\N	\N	2026-06-16 10:39:14.042208+00
13d774a3-03c7-4187-8c35-bf0f8105bc31	61825833-e8b8-41c7-b1ba-50f931c3ec96	delete_item	item	4a3bb9de-ecf8-405d-bf2d-517731b2fd12	\N	\N	\N	2026-06-16 10:39:17.257828+00
5215e9fe-4922-49e4-93dc-9de504738218	61825833-e8b8-41c7-b1ba-50f931c3ec96	create_item	item	ff8ec34e-b0ab-4d96-b3b7-3d7972131fb4	\N	{"name": "Mini Drill", "item_type": "quantifiable"}	\N	2026-06-16 10:39:26.582482+00
c974bdee-a8d5-4b3f-82f4-70164974c634	61825833-e8b8-41c7-b1ba-50f931c3ec96	create_item	item	a3be5808-1888-4c62-9390-264becdb49c8	\N	{"name": "3D Printer", "item_type": "quantifiable"}	\N	2026-06-16 10:39:39.563665+00
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.items (id, item_type, sku, name, category, description, status, created_by, created_at, updated_at, deleted_at, item_model) FROM stdin;
638a8750-eef2-4300-b6aa-af85c71e269b	trackable	\N	Charger	\N	\N	active	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:36:54.989436+00	2026-06-16 09:36:54.989436+00	\N	Asus
3f37262a-7606-4ce2-85e1-ee300b7540f1	quantifiable	\N	Korean Blueberry	Electronics	\N	active	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:24:24.61249+00	2026-06-16 10:39:13.731039+00	2026-06-16 10:39:13.731039+00	\N
ff8ec34e-b0ab-4d96-b3b7-3d7972131fb4	quantifiable	\N	Mini Drill	\N	\N	active	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 10:39:26.453452+00	2026-06-16 10:39:26.453452+00	\N	\N
a3be5808-1888-4c62-9390-264becdb49c8	quantifiable	\N	3D Printer	\N	\N	active	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 10:39:39.465274+00	2026-06-16 10:39:39.465274+00	\N	\N
4a3bb9de-ecf8-405d-bf2d-517731b2fd12	quantifiable	TEST-BEAKER-250	Test Beaker 250ml	\N	Scanner smoke-test fixture	active	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:54:51.983696+00	2026-06-16 14:34:43.875034+00	\N	\N
11111111-1111-1111-1111-111111111111	trackable	\N	Test Microscope	\N	\N	active	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 14:49:54.815319+00	2026-06-16 14:49:54.815319+00	\N	\N
\.


--
-- Data for Name: ble_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ble_tags (id, tag_code, item_id, assigned_at, assigned_by, is_active, created_at, name) FROM stdin;
219a492d-54ea-4572-b7d0-2aa227ceceed	48:87:2D:9D:A6:E3	638a8750-eef2-4300-b6aa-af85c71e269b	2026-06-16 09:37:08.05181+00	61825833-e8b8-41c7-b1ba-50f931c3ec96	t	2026-06-16 09:36:15.008539+00	Tag 1
\.


--
-- Data for Name: checkout_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.checkout_transactions (id, checked_out_by, processed_by, status, notes, created_at, updated_at, tracking_status, tracking_notes, approved_at, borrowed_at, returned_at, rejected_at, request_number) FROM stdin;
\.


--
-- Data for Name: item_lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.item_lots (id, item_id, lot_code, quantity_total, quantity_on_hand, quantity_out, purchased_at, expires_at, notes, created_at, updated_at) FROM stdin;
aa867a5b-9693-4a96-9f12-d7b8e4aad88e	4a3bb9de-ecf8-405d-bf2d-517731b2fd12	LOT-2026-001	50	50	0	2026-06-16	2026-12-16	\N	2026-06-16 09:54:51.983696+00	2026-06-16 09:54:51.983696+00
22222222-2222-2222-2222-222222222222	11111111-1111-1111-1111-111111111111	LOT-EXPIRED-001	5	5	0	\N	2026-06-11	\N	2026-06-16 14:49:54.815319+00	2026-06-16 14:49:54.815319+00
33333333-3333-3333-3333-333333333333	11111111-1111-1111-1111-111111111111	LOT-SOON-001	5	0	0	\N	2026-06-19	\N	2026-06-16 14:49:54.815319+00	2026-06-16 14:49:54.815319+00
44444444-4444-4444-4444-444444444444	11111111-1111-1111-1111-111111111111	LOT-MONTH-001	5	5	0	\N	2026-07-06	\N	2026-06-16 14:49:54.815319+00	2026-06-16 14:49:54.815319+00
\.


--
-- Data for Name: checkout_transaction_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.checkout_transaction_items (id, transaction_id, item_id, lot_id, quantity_out, quantity_returned, created_at, lot_selected_automatically, selection_method) FROM stdin;
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rooms (id, name, building, floor, description, created_at, deleted_at) FROM stdin;
af008d1b-6931-4e2a-adb9-418d6c508f40	Internet Laboratory	\N	\N	\N	2026-06-16 09:36:28.330455+00	\N
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (id, device_code, room_id, name, label, rssi_range, last_heartbeat, offline_since, is_active, created_at) FROM stdin;
186532dc-4713-44c1-9963-c03c22a0273b	A1	\N	Internet Laboratory Gateway	Internet Laboratory Gateway	-70	\N	2026-06-16 09:36:05.447114+00	t	2026-06-16 09:35:43.196396+00
\.


--
-- Data for Name: device_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_events (id, device_id, tag_id, tag_code, room_id, rssi, event_type, recorded_at) FROM stdin;
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folders (id, parent_id, name, created_by, created_at, updated_at, deleted_at) FROM stdin;
27ed4332-64c4-484e-92a2-8e3f4ee60848	\N	sub	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:25:02.912323+00	2026-06-16 09:25:02.912323+00	\N
3243552f-891c-45a1-a616-c23480b4f36e	27ed4332-64c4-484e-92a2-8e3f4ee60848	New Folder	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:26:02.524399+00	2026-06-16 09:26:02.524399+00	\N
f0cc7775-390b-41c6-b770-e3a0a92b6864	\N	Qwerty	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 14:33:06.460427+00	2026-06-16 14:33:06.460427+00	\N
077ce102-a37b-4170-9228-87d4c31171c5	\N	Qwerty1	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 14:33:33.398309+00	2026-06-16 14:33:33.398309+00	\N
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, folder_id, name, mime_type, size_bytes, storage_path, version, uploaded_by, created_at, updated_at, deleted_at, upload_batch_id) FROM stdin;
7b1be599-1fc0-45ac-92db-e4e4d5af9b9c	3243552f-891c-45a1-a616-c23480b4f36e	Circuit.png	image/png	308288	8cde6a37-96df-455d-88ce-8e383a33b891.png	1	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:39:06.024951+00	2026-06-16 09:39:06.024951+00	\N	\N
b9f98c9d-025f-43c3-b461-8bed6fa290cb	27ed4332-64c4-484e-92a2-8e3f4ee60848	Flowchart_inventory_small_start_end_fixed-5. BLE Tracking and Audit.drawio.png	image/png	193971	63e1db0f-be00-447f-a0dd-9fe07a9eb92f.png	1	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:42:19.212945+00	2026-06-16 09:42:19.212945+00	\N	\N
921c03a0-34cd-4636-a308-a6153d5d0f3d	27ed4332-64c4-484e-92a2-8e3f4ee60848	Flowchart_inventory_small_start_end_fixed-3. Document Management.drawio.png	image/png	154663	30268a52-b236-44f1-9e89-e141c3e5ea29.png	1	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:42:19.573631+00	2026-06-16 09:42:19.573631+00	\N	\N
86dc20a6-9da3-4475-9160-6c32c41d8266	27ed4332-64c4-484e-92a2-8e3f4ee60848	Flowchart_inventory_small_start_end_fixed-2. Authentication.drawio.png	image/png	152534	49c19757-e679-4bfa-b955-a31b16fb0c33.png	1	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:42:19.894565+00	2026-06-16 09:42:19.894565+00	\N	\N
7f76b05b-89c7-44e3-ba61-13078921d9b2	27ed4332-64c4-484e-92a2-8e3f4ee60848	Flowchart_inventory_small_start_end_fixed-1. System Architecture.drawio.png	image/png	155900	5a6a1285-6c63-402f-8943-fd0d6fb1d452.png	1	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:42:20.222715+00	2026-06-16 09:42:20.222715+00	\N	\N
ad3afc90-2a58-427f-b8b8-242408fba8f2	27ed4332-64c4-484e-92a2-8e3f4ee60848	Flowchart_inventory_small_start_end_fixed-Revise Inventory.drawio.png	image/png	216098	21f85c07-9f77-4ebb-9b15-9eb7e9cada20.png	1	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 09:42:20.628732+00	2026-06-16 09:42:20.628732+00	\N	\N
0b2ea92e-84b5-4387-b065-6922ee28ea9e	077ce102-a37b-4170-9228-87d4c31171c5	Ss	image/jpeg	430026	a15fd7de-8609-4bc9-af70-930d7421ebc3.jpg	1	61825833-e8b8-41c7-b1ba-50f931c3ec96	2026-06-16 14:34:43.042337+00	2026-06-16 14:35:04.719255+00	\N	\N
\.


--
-- Data for Name: document_activity_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_activity_logs (id, document_id, folder_id, actor_id, action, metadata, created_at) FROM stdin;
011190e5-6e84-4fa7-a449-c470d2f135d3	\N	27ed4332-64c4-484e-92a2-8e3f4ee60848	61825833-e8b8-41c7-b1ba-50f931c3ec96	create_folder	\N	2026-06-16 09:25:02.934597+00
9e72c69f-284e-4501-94bb-1ddea9ad0c91	\N	3243552f-891c-45a1-a616-c23480b4f36e	61825833-e8b8-41c7-b1ba-50f931c3ec96	create_folder	\N	2026-06-16 09:26:02.571228+00
34dbd747-7823-4fa6-a22b-7bb2fe56398e	7b1be599-1fc0-45ac-92db-e4e4d5af9b9c	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	upload	{"size": 308288, "folder_id": "3243552f-891c-45a1-a616-c23480b4f36e", "mime_type": "image/png"}	2026-06-16 09:39:06.062682+00
1ac1e81f-523e-4a7a-acd9-3968447838fe	7b1be599-1fc0-45ac-92db-e4e4d5af9b9c	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	download	\N	2026-06-16 09:39:13.704796+00
76408fa2-5d0f-4caf-b073-1744c56e9aa5	b9f98c9d-025f-43c3-b461-8bed6fa290cb	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	upload	{"size": 193971, "folder_id": "27ed4332-64c4-484e-92a2-8e3f4ee60848", "mime_type": "image/png"}	2026-06-16 09:42:19.241971+00
500b035e-45e4-4ad7-bc5e-36eec66047b0	921c03a0-34cd-4636-a308-a6153d5d0f3d	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	upload	{"size": 154663, "folder_id": "27ed4332-64c4-484e-92a2-8e3f4ee60848", "mime_type": "image/png"}	2026-06-16 09:42:19.592257+00
f264e6c0-cfa4-4856-b8e2-0d37be209599	86dc20a6-9da3-4475-9160-6c32c41d8266	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	upload	{"size": 152534, "folder_id": "27ed4332-64c4-484e-92a2-8e3f4ee60848", "mime_type": "image/png"}	2026-06-16 09:42:19.93398+00
b33cbae9-db47-44b5-8d23-b63644c4a752	7f76b05b-89c7-44e3-ba61-13078921d9b2	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	upload	{"size": 155900, "folder_id": "27ed4332-64c4-484e-92a2-8e3f4ee60848", "mime_type": "image/png"}	2026-06-16 09:42:20.275574+00
50390666-8ace-448d-912d-f6a981c9a8e4	ad3afc90-2a58-427f-b8b8-242408fba8f2	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	upload	{"size": 216098, "folder_id": "27ed4332-64c4-484e-92a2-8e3f4ee60848", "mime_type": "image/png"}	2026-06-16 09:42:20.675673+00
d5231212-0506-422a-86b4-0425f6910180	ad3afc90-2a58-427f-b8b8-242408fba8f2	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	download	\N	2026-06-16 09:42:30.097067+00
298f1884-3cbf-4c0a-8012-0bdb07f627b4	\N	f0cc7775-390b-41c6-b770-e3a0a92b6864	61825833-e8b8-41c7-b1ba-50f931c3ec96	create_folder	\N	2026-06-16 14:33:06.512427+00
eb91c4d5-226c-4e6f-bfd1-c08bad1e3baf	\N	077ce102-a37b-4170-9228-87d4c31171c5	61825833-e8b8-41c7-b1ba-50f931c3ec96	create_folder	\N	2026-06-16 14:33:33.437067+00
8471c8dd-10de-4f43-a39e-6f9624e0f0db	0b2ea92e-84b5-4387-b065-6922ee28ea9e	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	upload	{"size": 430026, "folder_id": "077ce102-a37b-4170-9228-87d4c31171c5", "mime_type": "image/jpeg"}	2026-06-16 14:34:43.097414+00
f612fd4d-7ea7-4893-9e9b-85f37347c623	0b2ea92e-84b5-4387-b065-6922ee28ea9e	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	rename	{"name": "Screenshot_20260616_222938_Chrome.jpg"}	2026-06-16 14:34:54.947535+00
cdc6ce5f-6284-4e10-a94e-f784d4b95fd5	0b2ea92e-84b5-4387-b065-6922ee28ea9e	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	rename	{"name": "Ss"}	2026-06-16 14:35:04.755778+00
2d8cbf06-29e3-4c54-b9be-de83522e9232	0b2ea92e-84b5-4387-b065-6922ee28ea9e	\N	61825833-e8b8-41c7-b1ba-50f931c3ec96	download	\N	2026-06-16 14:35:28.679556+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, can_checkout_quantifiable, created_at) FROM stdin;
ee466c55-d4ec-40f6-9314-45c8eb868336	admin	Full system access	t	2026-06-16 09:12:38.893702+00
2dd966a7-24a6-46b4-b0ff-791adb08adf8	staff	Inventory and document management	t	2026-06-16 09:12:38.893702+00
9066cb43-df75-4866-bf00-45b9354236c6	student	Limited access per policy	f	2026-06-16 09:13:24.227033+00
\.


--
-- Data for Name: document_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_permissions (id, document_id, folder_id, user_id, role_id, permission, inherit, granted_by, granted_at) FROM stdin;
\.


--
-- Data for Name: document_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_versions (id, document_id, version, storage_path, size_bytes, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: item_location_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.item_location_history (id, item_id, room_id, device_id, presence_status, rssi, conflict_meta, recorded_at) FROM stdin;
\.


--
-- Data for Name: item_presence_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.item_presence_state (item_id, current_room_id, presence_status, last_seen_at, last_device_id, last_rssi, missing_since, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, type, title, message, entity_type, entity_id, is_read, metadata, created_at, read_at) FROM stdin;
79f5ce70-79cc-418a-ab46-588f39f05aa6	61825833-e8b8-41c7-b1ba-50f931c3ec96	expiring_item	Item Expiring Soon	Item Test Microscope is expiring on 2026-06-11	item	11111111-1111-1111-1111-111111111111	f	{"quantity": 5, "item_name": "Test Microscope", "expires_at": "2026-06-11"}	2026-06-16 14:49:54.815319+00	\N
\.


--
-- Data for Name: report_exports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_exports (id, user_id, report_type, file_name, file_path, format, filters, status, error_message, created_at, completed_at, download_count) FROM stdin;
\.


--
-- Data for Name: return_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_transactions (id, checkout_transaction_id, returned_by, processed_by, notes, created_at) FROM stdin;
\.


--
-- Data for Name: return_transaction_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.return_transaction_items (id, return_transaction_id, checkout_item_id, quantity_returned, created_at) FROM stdin;
\.


--
-- Data for Name: scanner_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scanner_sessions (id, user_id, session_id, scanner_type, focused_field, last_scan, scan_count, created_at, last_used, metadata) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (id, name, applied_at) FROM stdin;
1	20240425000001_users_and_roles.js	2026-06-16 09:13:24.227033+00
2	20240425000002_documents.js	2026-06-16 09:13:24.316065+00
3	20240425000003_inventory_base.js	2026-06-16 09:13:24.408122+00
4	20240425000004_trackable_inventory.js	2026-06-16 09:13:24.439522+00
5	20240425000005_quantifiable_inventory.js	2026-06-16 09:13:24.464369+00
6	20240425000006_auditing.js	2026-06-16 09:13:24.489521+00
7	20240426000007_api_fixes.js	2026-06-16 09:13:24.514663+00
8	20240426000008_ble_enhancements.js	2026-06-16 09:13:24.548401+00
9	20240426000009_fix_rooms_deleted_at.js	2026-06-16 09:13:24.581418+00
10	20240426000010_add_sku_to_items.js	2026-06-16 09:13:24.598008+00
11	20240430000011_update_checkout_status_constraint.js	2026-06-16 09:13:24.647938+00
12	20240506000012_deduplicate_permissions.js	2026-06-16 09:13:24.665042+00
13	20240507000013_add_item_model_to_items.js	2026-06-16 09:13:24.689512+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role_id, assigned_at, assigned_by) FROM stdin;
61825833-e8b8-41c7-b1ba-50f931c3ec96	ee466c55-d4ec-40f6-9314-45c8eb868336	2026-06-16 09:13:25.729962+00	61825833-e8b8-41c7-b1ba-50f931c3ec96
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, session_token, ip_address, user_agent, last_active, created_at, expires_at) FROM stdin;
\.


--
-- Name: checkout_transactions_request_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.checkout_transactions_request_number_seq', 1, false);


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.schema_migrations_id_seq', 13, true);


--
-- PostgreSQL database dump complete
--

\unrestrict ukVt9jxwK6B1ZDlrd611ev4txBtMLN1NbUeCuydBdckVh6qp7twEfNJ6jpnFwcw

